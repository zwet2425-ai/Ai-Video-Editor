package com.aivideoeditor.v03.runtime;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.OpenableColumns;
import androidx.core.content.FileProvider;
import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.PluginMethod;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@CapacitorPlugin(name = "AIVideoRuntime")
public class AIVideoRuntimePlugin extends Plugin {
  @PluginMethod
  public void pickVideo(PluginCall call) {
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("video/*");
    startActivityForResult(call, intent, "videoPickerResult");
  }

  @ActivityCallback
  private void videoPickerResult(PluginCall call, ActivityResult result) {
    if (call == null || result == null || result.getResultCode() != Activity.RESULT_OK || result.getData() == null) { call.reject("VIDEO_PICK_CANCELLED"); return; }
    String uri = result.getData().getDataString();
    if (uri == null) { call.reject("VIDEO_PICK_CANCELLED"); return; }
    Uri parsed = Uri.parse(uri);
    JSObject ret = new JSObject();
    ret.put("uri", uri);
    ret.put("name", queryName(parsed) == null ? "video.mp4" : queryName(parsed));
    ret.put("mimeType", getContext().getContentResolver().getType(parsed) == null ? "video/mp4" : getContext().getContentResolver().getType(parsed));
    call.resolve(ret);
  }

  @PluginMethod
  public void render(PluginCall call) {
    String inputUri = call.getString("inputUri");
    JSArray args = call.getArray("ffmpegArgs");
    if (inputUri == null || inputUri.isEmpty()) { call.reject("INPUT_URI_REQUIRED"); return; }
    if (args == null || args.length() == 0) { call.reject("FFMPEG_ARGS_REQUIRED"); return; }
    try {
      File input = copyUriToCache(Uri.parse(inputUri), "input-" + System.currentTimeMillis() + ".mp4");
      File output = new File(getContext().getCacheDir(), "aive-render-" + timestamp() + ".mp4");
      String command = buildCommand(args, input.getAbsolutePath(), output.getAbsolutePath());
      FFmpegKit.executeAsync(command, session -> {
        if (ReturnCode.isSuccess(session.getReturnCode())) {
          Uri outUri = publishOutput(output);
          JSObject ret = new JSObject();
          ret.put("status", "complete");
          ret.put("outputUri", outUri.toString());
          ret.put("mimeType", "video/mp4");
          ret.put("fileName", output.getName());
          call.resolve(ret);
        } else {
          call.reject("FFMPEG_FAILED", session.getFailStackTrace() == null ? "FFmpeg failed" : session.getFailStackTrace());
        }
      });
    } catch (Exception e) { call.reject("NATIVE_RENDER_FAILED", e.getMessage(), e); }
  }

  private Uri publishOutput(File rendered) throws Exception {
    if (android.os.Build.VERSION.SDK_INT >= 29) {
      android.content.ContentValues values = new android.content.ContentValues();
      values.put(android.provider.MediaStore.Video.Media.DISPLAY_NAME, rendered.getName());
      values.put(android.provider.MediaStore.Video.Media.MIME_TYPE, "video/mp4");
      values.put(android.provider.MediaStore.Video.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_MOVIES + "/AI Video Editor");
      Uri uri = getContext().getContentResolver().insert(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
      if (uri == null) throw new IllegalStateException("OUTPUT_MEDIASTORE_INSERT_FAILED");
      try (java.io.InputStream in = new java.io.FileInputStream(rendered); java.io.OutputStream out = getContext().getContentResolver().openOutputStream(uri)) {
        if (out == null) throw new IllegalStateException("OUTPUT_STREAM_FAILED");
        byte[] buf = new byte[1024 * 1024]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
      }
      return uri;
    }
    return FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", rendered);
  }

  private String buildCommand(JSArray args, String input, String output) throws Exception {
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < args.length(); i++) {
      String s = args.getString(i);
      if (s == null || s.isEmpty()) continue;
      s = s.replace("{INPUT}", quote(input)).replace("{OUTPUT}", quote(output));
      if (b.length() > 0) b.append(' ');
      b.append(s);
    }
    return b.toString();
  }
  private String quote(String s) { return "'" + s.replace("'", "'\\''") + "'"; }
  private File copyUriToCache(Uri uri, String name) throws Exception {
    File out = new File(getContext().getCacheDir(), name);
    try (java.io.InputStream in = getContext().getContentResolver().openInputStream(uri); FileOutputStream os = new FileOutputStream(out)) {
      if (in == null) throw new IllegalStateException("Unable to open selected video");
      byte[] buf = new byte[1024 * 1024]; int n; while ((n = in.read(buf)) != -1) os.write(buf, 0, n);
    }
    return out;
  }
  private String queryName(Uri uri) {
    try (android.database.Cursor c = getContext().getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
      if (c != null && c.moveToFirst()) return c.getString(0);
    } catch (Exception ignored) {}
    return null;
  }
  private String timestamp() { return new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()); }
}
