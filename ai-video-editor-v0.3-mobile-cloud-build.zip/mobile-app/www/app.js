const $ = s => document.querySelector(s);
const video = $('#video');
const previewCanvas = $('#previewCanvas');
const empty = $('#emptyPreview');
const statusEl = $('#status');
const planEl = $('#executionPlan');
const state = {
  videoUrl: null,
  videoFile: null,
  musicFile: null,
  actions: new Map(),
  preview: { raf: null, lastTs: 0 },
  media: { width: 0, height: 0, duration: 0 },
  dirty: true,
  captions: {segments: [], sourceFormat: null, fileName: null},
  nativeInputUri: null
};

/* =========================
   FUNCTION REGISTRY
   ========================= */
const registry = [
 {id:'split',name:'SPLIT',recommend:true,dependsOn:[],fields:[['select','mode','Split By',['Duration','Equal Parts']],['text','duration','Duration','06:00']]},
 {id:'speed',name:'SPEED',recommend:true,dependsOn:['trim','split'],fields:[['select','mode','Choose Function',['Normal Speed','Fast','Slow','Speed Ramp','Custom']],['number','speed','Speed','1.00'],['select','applyTo','Apply To',['Entire Video','Selected Clip','Selected Range']]]},
 {id:'trim',name:'TRIM',dependsOn:[],fields:[['text','start','Start','00:00:00'],['text','end','End','00:01:30']]},
 {id:'resize',name:'RESIZE',dependsOn:['crop'],fields:[['number','width','Width','1920'],['number','height','Height','1080'],['checkbox','lock','Lock Ratio','on']]},
 {id:'crop',name:'CROP',dependsOn:[],fields:[['select','mode','Choose Function',['Custom','Center']],['number','width','Width','1080'],['number','height','Height','1080'],['number','x','Position X','0'],['number','y','Position Y','0']]},
 {id:'transition',name:'TRANSITION',dependsOn:['split'],fields:[['select','mode','Choose Function',['Fade','Dissolve','Slide','Zoom','Blur']],['number','duration','Duration','0.50'],['select','applyTo','Apply To',['Auto','Selected Clip']]]},
 {id:'beatSync',name:'BEAT SYNC',recommend:true,dependsOn:['split'],fields:[['select','mode','Choose Function',['Cut on Beat','Transition on Beat','Speed Change on Beat','Zoom on Beat','Custom']],['number','sensitivity','Sensitivity','75'],['number','offset','Beat Offset (ms)','0']]},
 {id:'beatCut',name:'BEAT CUT',recommend:true,dependsOn:['beatSync','split'],fields:[['select','frequency','Cut Frequency',['Every Beat','Every 2 Beats','Strong Beats']],['number','minClip','Minimum Clip (sec)','0.50'],['number','sensitivity','Sensitivity','75'],['number','offset','Offset (ms)','0']]},
 {id:'speedRamp',name:'SPEED RAMP',recommend:true,dependsOn:['speed'],fields:[['select','mode','Choose Function',['Normal Ramp','Fast In','Fast Out','Fast → Slow','Slow → Fast','Custom','Beat Ramp']],['number','start','Start Speed','1.00'],['number','peak','Peak Speed','2.50'],['number','end','End Speed','1.00'],['number','duration','Ramp Duration (sec)','2.00']]},
 {id:'zoomMotion',name:'ZOOM / MOTION',recommend:true,dependsOn:[],fields:[['select','mode','Choose Function',['Zoom In','Zoom Out','Pan Left','Pan Right','Auto Zoom','Beat Zoom','Custom Motion']],['number','amount','Amount','1.15'],['number','duration','Duration (sec)','1.00'],['select','direction','Direction',['In','Out']],['select','applyTo','Apply To',['Entire Video','Beat']]]},
 {id:'caption',name:'AUTO CAPTION',recommend:true,dependsOn:[],fields:[['select','language','Language',['Auto Detect','English','Myanmar','Thai']],['select','style','Style',['Trend','Clean','Minimal']],['select','position','Position',['Center','Bottom','Top']],['select','animation','Animation',['Pop','Fade','None']]]}
];

const recommendDefaults = {
  speed: {mode:'Fast',speed:'1.25',applyTo:'Entire Video'},
  trim: {start:'00:00:00',end:'00:00:30'},
  crop: {mode:'Center',width:'1080',height:'1080',x:'0',y:'0'},
  resize: {width:'1080',height:'1080',lock:true},
  transition: {mode:'Dissolve',duration:'0.50',applyTo:'Auto'},
  beatSync: {mode:'Cut on Beat',sensitivity:'75',offset:'0'},
  beatCut: {frequency:'Every 2 Beats',minClip:'0.50',sensitivity:'75',offset:'0'},
  speedRamp: {mode:'Beat Ramp',start:'1.00',peak:'2.50',end:'1.00',duration:'2.00'},
  zoomMotion: {mode:'Auto Zoom',amount:'1.15',duration:'1.00',direction:'In',applyTo:'Entire Video'},
  caption: {language:'Auto Detect',style:'Trend',position:'Bottom',animation:'Pop'}
};

function renderFunctions(){
  $('#functionList').innerHTML = registry.map(fn => `
   <div class="card" id="card-${fn.id}">
    <div class="card-head">
      <div><span class="fn-name">${fn.name}</span>${fn.recommend?'<span class="recommend">AI RECOMMEND</span>':''}</div>
      <button class="toggle" data-toggle="${fn.id}" aria-label="Toggle ${fn.name}"></button>
    </div>
    <div class="controls">
      ${fn.recommend ? `<button class="recommend-btn" data-recommend="${fn.id}">APPLY AI RECOMMENDATION</button>` : ''}
      ${fn.fields.map(f=>fieldHtml(fn,f)).join('')}
      <div class="validation" data-validation="${fn.id}"></div>
    </div>
   </div>`).join('');

  document.querySelectorAll('[data-toggle]').forEach(b=>b.addEventListener('click',()=>toggle(b.dataset.toggle)));
  document.querySelectorAll('[data-field]').forEach(el=>{
    el.addEventListener('input',()=>updateAction(el.dataset.field));
    el.addEventListener('change',()=>updateAction(el.dataset.field));
  });
  document.querySelectorAll('[data-recommend]').forEach(b=>b.addEventListener('click',()=>applyRecommendation(b.dataset.recommend)));
  const captionCard = $('#card-caption');
  if (captionCard) {
    const controls = captionCard.querySelector('.controls');
    const box = document.createElement('div');
    box.className = 'caption-import-box';
    box.innerHTML = `<div class="field"><label>Manual Caption / SRT / VTT</label><input id="captionFile" type="file" accept=".srt,.vtt,text/vtt,application/x-subrip"><div id="captionImportStatus" class="caption-import-status">No caption file imported — AI transcription can be used later.</div></div>`;
    controls.insertBefore(box, controls.querySelector('.validation'));
    $('#captionFile').addEventListener('change', async e => {
      const file=e.target.files?.[0]; if(!file) return;
      try {
        const text=await file.text();
        const parsed=parseSubtitleText(text);
        if(!parsed.length) throw new Error('No valid subtitle entries found.');
        state.captions={segments:parsed,sourceFormat:file.name.toLowerCase().endsWith('.vtt')?'vtt':'srt',fileName:file.name};
        const a=state.actions.get('caption');
        if(a){ a.params.segments=parsed; a.params.sourceFormat=state.captions.sourceFormat; updateAction('caption'); }
        $('#captionImportStatus').textContent=`Imported ${parsed.length} caption segments from ${file.name}`;
        statusEl.textContent=`Manual captions ready · ${parsed.length} segments`;
      } catch(err) {
        state.captions={segments:[],sourceFormat:null,fileName:null};
        $('#captionImportStatus').textContent=`Import failed: ${err.message}`;
      }
    });
  }
}

function fieldHtml(fn,f){
  const [type,key,label,val] = f;
  const base=`data-field="${fn.id}" data-key="${key}"`;
  if(type==='select') return `<div class="field"><label>${label}</label><select ${base}>${val.map(x=>`<option>${x}</option>`).join('')}</select></div>`;
  if(type==='checkbox') return `<div class="field checkbox-field"><label>${label}</label><input type="checkbox" ${base} checked></div>`;
  return `<div class="field"><label>${label}</label><input type="${type==='number'?'number':'text'}" value="${val}" ${base}></div>`;
}

function readParams(id){
  const params={};
  document.querySelectorAll(`[data-field="${id}"]`).forEach(el=>params[el.dataset.key]=el.type==='checkbox'?el.checked:el.value);
  return params;
}
function writeParams(id, params){
  document.querySelectorAll(`[data-field="${id}"]`).forEach(el=>{
    if(!(el.dataset.key in params)) return;
    if(el.type==='checkbox') el.checked=!!params[el.dataset.key];
    else el.value=params[el.dataset.key];
  });
}

function validateAction(id, params){
  const errors=[];
  if(id==='speed' && (!(Number(params.speed)>0) || Number(params.speed)>8)) errors.push('Speed must be > 0 and ≤ 8.');
  if(id==='resize' && (!(Number(params.width)>0) || !(Number(params.height)>0))) errors.push('Width and height must be positive.');
  if(id==='crop' && (!(Number(params.width)>0) || !(Number(params.height)>0))) errors.push('Crop size must be positive.');
  if(id==='zoomMotion' && (!(Number(params.amount)>=1) || Number(params.amount)>4)) errors.push('Zoom amount must be 1–4.');
  if(id==='speedRamp' && [params.start,params.peak,params.end,params.duration].some(v=>!(Number(v)>0))) errors.push('Ramp values must be positive.');
  if(id==='transition' && (!(Number(params.duration)>=0) || Number(params.duration)>10)) errors.push('Transition duration must be 0–10 sec.');
  if(id==='trim'){
    const s=timeToSec(params.start), e=timeToSec(params.end);
    if(s<0 || e<=s) errors.push('Trim end must be after trim start.');
    if(state.media.duration && e>state.media.duration+0.05) errors.push(`Trim end exceeds video duration (${state.media.duration.toFixed(2)}s).`);
  }
  const el=$(`[data-validation="${id}"]`);
  if(el) el.textContent=errors.join(' ');
  return errors;
}

function applyRecommendation(id){
  const rec=recommendDefaults[id];
  if(!rec) return;
  writeParams(id,rec);
  if(!state.actions.has(id)) toggle(id);
  else updateAction(id);
  statusEl.textContent=`AI recommendation applied: ${registry.find(x=>x.id===id).name}`;
}

function toggle(id){
  const fn=registry.find(x=>x.id===id), card=$(`#card-${id}`), btn=card.querySelector('.toggle');
  if(state.actions.has(id)){
    state.actions.delete(id);
    card.classList.remove('active'); btn.classList.remove('on');
  } else {
    const params=readParams(id);
    if(validateAction(id,params).length) return;
    state.actions.set(id,{id,name:fn.name,params});
    card.classList.add('active'); btn.classList.add('on');
  }
  renderStack(); buildExecutionPlan(); markPreviewDirty(); applyPreview();
}
function updateAction(id){
  if(!state.actions.has(id)) return;
  const params=readParams(id);
  validateAction(id,params);
  state.actions.get(id).params=params;
  renderStack(); buildExecutionPlan(); markPreviewDirty(); applyPreview();
}

function parseSubtitleText(text){
  const normalized=String(text).replace(/\r/g,'');
  const blocks=normalized.split(/\n{2,}/).map(x=>x.trim()).filter(Boolean);
  const out=[];
  for(const block of blocks){
    const lines=block.split('\n').map(x=>x.trim()).filter(Boolean);
    const timeIndex=lines.findIndex(x=>x.includes('-->'));
    if(timeIndex<0) continue;
    const m=lines[timeIndex].match(/(\d{1,2}:\d{2}(?::\d{2})?[.,]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}(?::\d{2})?[.,]\d{1,3})/);
    if(!m) continue;
    const start=parseSubTime(m[1]), end=parseSubTime(m[2]);
    const caption=lines.slice(timeIndex+1).join(' ').replace(/<[^>]+>/g,'').trim();
    if(end>start && caption) out.push({start,end,text:caption});
  }
  return out.sort((a,b)=>a.start-b.start);
}
function parseSubTime(v){
  const x=String(v).replace(',', '.').split(':').map(Number);
  if(x.length===3) return x[0]*3600+x[1]*60+x[2];
  if(x.length===2) return x[0]*60+x[1];
  return Number(x[0])||0;
}

function renderStack(){
  const el=$('#actionStack');
  if(!state.actions.size){el.innerHTML='<div class="muted">No active functions</div>';return;}
  el.innerHTML=[...state.actions.values()].map((a,i)=>`
    <div class="stack-item">
      <div class="active-dot"></div><div class="num">${String(i+1).padStart(2,'0')}</div>
      <div class="stack-main"><div class="stack-name">${a.name}</div>
      <div class="stack-detail">${detail(a.params)}</div></div>
    </div>`).join('');
}
function detail(p){
  return Object.entries(p).map(([k,v])=>`${k}: ${typeof v==='boolean'?(v?'ON':'OFF'):v}`).join(' · ');
}

/* =========================
   EXECUTION PLANNER
   ========================= */
function buildExecutionPlan(){
  const active=[...state.actions.keys()];
  const nodes=new Map(active.map(id=>[id,registry.find(x=>x.id===id)]));
  const indeg=new Map(active.map(id=>[id,0]));
  const edges=new Map(active.map(id=>[id,[]]));
  for(const id of active){
    for(const dep of (nodes.get(id)?.dependsOn||[])){
      if(!nodes.has(dep)) continue;
      edges.get(dep).push(id);
      indeg.set(id,indeg.get(id)+1);
    }
  }
  const queue=active.filter(id=>indeg.get(id)===0);
  const order=[];
  while(queue.length){
    const id=queue.shift(); order.push(id);
    for(const next of edges.get(id)){
      indeg.set(next,indeg.get(next)-1);
      if(indeg.get(next)===0) queue.push(next);
    }
  }
  // deterministic fallback for any registry dependency cycle
  active.forEach(id=>{if(!order.includes(id)) order.push(id);});
  const plan=order.map((id,i)=>({step:i+1,id,name:nodes.get(id).name,params:state.actions.get(id).params}));
  state.executionPlan=plan;
  planEl.innerHTML=plan.length
    ? plan.map(p=>`<div class="plan-item"><b>${String(p.step).padStart(2,'0')}</b><span>${p.name}</span><small>${p.id}</small></div>`).join('')
    : '<div class="muted">Execution plan is empty</div>';
  return plan;
}

/* =========================
   MEDIA + PREVIEW ENGINE
   ========================= */
function markPreviewDirty(){state.dirty=true;}
function applyPreview(){
  if(!video.src) return;
  statusEl.textContent=`Preview: ${state.actions.size} active function${state.actions.size===1?'':'s'}`;
  ensureCanvasLoop();
}
function ensureCanvasLoop(){
  if(state.preview.raf) return;
  const ctx=previewCanvas.getContext('2d');
  const loop=()=>{
    state.preview.raf=requestAnimationFrame(loop);
    if(video.readyState<2 || video.paused) return;
    drawPreview(ctx);
  };
  loop();
}
function drawPreview(ctx){
  const w=previewCanvas.width, h=previewCanvas.height;
  const active=state.actions;
  ctx.clearRect(0,0,w,h);
  if(!video.videoWidth) return;
  let scale=1, zoom=1;
  const zm=active.get('zoomMotion');
  if(zm) zoom=Math.max(1,Math.min(4,Number(zm.params.amount)||1));
  if(active.has('crop')){
    const p=active.get('crop').params;
    const cw=Math.max(1,Number(p.width)||video.videoWidth);
    const ch=Math.max(1,Number(p.height)||video.videoHeight);
    scale=Math.min(video.videoWidth/cw, video.videoHeight/ch);
  }
  const s=Math.max(scale,zoom);
  const dw=w*s, dh=h*s;
  ctx.save();
  ctx.translate((w-dw)/2,(h-dh)/2);
  ctx.drawImage(video,0,0,dw,dh);
  ctx.restore();
  if(active.has('caption')){
    const p=active.get('caption').params;
    ctx.font='700 24px system-ui';
    ctx.textAlign='center';
    ctx.fillStyle='white';
    ctx.strokeStyle='black';
    ctx.lineWidth=5;
    const y=p.position==='Top'?45:p.position==='Center'?h/2:h-35;
    ctx.strokeText('LIVE CAPTION PREVIEW',w/2,y);
    ctx.fillText('LIVE CAPTION PREVIEW',w/2,y);
  }
}

video.addEventListener('loadedmetadata',()=>{
  state.media={width:video.videoWidth,height:video.videoHeight,duration:video.duration};
  previewCanvas.width=Math.max(320,video.videoWidth);
  previewCanvas.height=Math.max(180,video.videoHeight);
  validateAll(); buildExecutionPlan(); markPreviewDirty();
  statusEl.textContent=`Video ready · ${video.videoWidth}×${video.videoHeight} · ${video.duration.toFixed(2)}s`;
});
video.addEventListener('timeupdate',()=>{
  const trim=state.actions.get('trim');
  if(trim){
    const s=timeToSec(trim.params.start), e=timeToSec(trim.params.end);
    if(video.currentTime<s) video.currentTime=s;
    if(video.currentTime>=e && !video.paused) video.pause();
  }
});
function validateAll(){state.actions.forEach((a)=>validateAction(a.id,a.params));}

function timeToSec(v){
  if(typeof v==='number') return v;
  const parts=String(v).split(':').map(Number);
  if(parts.some(Number.isNaN)) return -1;
  if(parts.length===3) return parts[0]*3600+parts[1]*60+parts[2];
  if(parts.length===2) return parts[0]*60+parts[1];
  return Number(parts[0])||0;
}

/* =========================
   RENDER ENGINE ADAPTER
   Browser-native render path.
   Final export is a real WebM render from the preview canvas.
   ========================= */
async function renderFinal(){
  if(!video.src){throw new Error('Upload a video first.');}
  const plan=buildExecutionPlan();
  if(!plan.length) throw new Error('Turn on at least one function.');
  validateAll();
  const invalid=[...state.actions.values()].some(a=>validateAction(a.id,a.params).length);
  if(invalid) throw new Error('Fix invalid parameters before RUN.');

  // Canvas + MediaRecorder gives an actual rendered output without modifying the source.
  // Audio is preserved separately only when the browser supports captureStream audio mixing.
  const canvasStream=previewCanvas.captureStream(30);
  const mime=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].find(MediaRecorder.isTypeSupported);
  if(!mime) throw new Error('This browser does not support WebM MediaRecorder export.');

  const recorder=new MediaRecorder(canvasStream,{mimeType:mime,videoBitsPerSecond:8000000});
  const chunks=[];
  recorder.ondataavailable=e=>{if(e.data.size) chunks.push(e.data);};
  const done=new Promise((resolve,reject)=>{
    recorder.onstop=()=>resolve(new Blob(chunks,{type:mime}));
    recorder.onerror=e=>reject(e.error||new Error('Render failed.'));
  });

  const oldTime=video.currentTime, wasPlaying=!video.paused;
  const trim=state.actions.get('trim');
  const start=trim?Math.max(0,timeToSec(trim.params.start)):0;
  const end=trim?Math.min(video.duration,timeToSec(trim.params.end)):video.duration;
  video.currentTime=start;
  await new Promise(r=>video.addEventListener('seeked',r,{once:true}));
  recorder.start(200);
  if(video.paused) await video.play().catch(()=>{});
  await new Promise(resolve=>{
    const tick=()=>{
      if(video.currentTime>=end-0.03 || video.ended){resolve();return;}
      requestAnimationFrame(tick);
    }; tick();
  });
  if(recorder.state!=='inactive') recorder.stop();
  if(video.pause) video.pause();
  video.currentTime=oldTime;
  if(wasPlaying) video.play().catch(()=>{});
  return done;
}

async function loadNativeVideo(){
  if(!window.AIVideoEditorNative) throw new Error('NATIVE_RUNTIME_UNAVAILABLE');
  const picked=await window.AIVideoEditorNative.pickVideo();
  state.nativeInputUri=picked.uri; state.videoFile=null; state.videoUrl=picked.uri;
  video.src=picked.uri; video.style.display='block'; empty.style.display='none';
  statusEl.textContent=`Device video loaded · ${picked.name||'video'}`;
}
$('#nativeVideoBtn').addEventListener('click',async()=>{try{await loadNativeVideo();}catch(err){statusEl.textContent=`Device picker: ${err.message}`;}});
$('#videoInput').addEventListener('change',async e=>{
  const file=e.target.files[0]; if(!file)return;
  state.nativeInputUri=null;
  if(state.videoUrl)URL.revokeObjectURL(state.videoUrl);
  state.videoFile=file;
  state.videoUrl=URL.createObjectURL(file);
  video.src=state.videoUrl;
  video.style.display='block';
  empty.style.display='none';
  statusEl.textContent='Video loaded — AI Recommend ready';
});
$('#musicInput').addEventListener('change',e=>{
  if(e.target.files[0]){state.musicFile=e.target.files[0];statusEl.textContent='Music loaded — beat analysis hook ready';}
});
$('#runBtn').addEventListener('click',()=>{
  const plan=buildExecutionPlan();
  $('#runSummary').textContent=plan.length
    ? `Execution order: ${plan.map(p=>p.name).join(' → ')}`
    : 'Nothing to render. Turn on at least one function.';
  $('#runModal').classList.remove('hidden');
});
$('#closeModal').addEventListener('click',()=>$('#runModal').classList.add('hidden'));
$('#confirmRun').addEventListener('click',async()=>{
  const btn=$('#confirmRun');
  btn.disabled=true; statusEl.textContent='Rendering final preview stream…';
  try{
    if(state.nativeInputUri && window.AIVideoEditorNative){
      const {compileMobileFFmpegArgs}=await import('./mobile-command-compiler.js');
      const ffmpegArgs=compileMobileFFmpegArgs({executionPlan:buildExecutionPlan(),captions:state.captions.segments});
      statusEl.textContent='Native FFmpeg rendering…';
      const result=await window.AIVideoEditorNative.render({inputUri:state.nativeInputUri,outputName:`aive-render-${Date.now()}.mp4`,executionPlan:state.executionPlan,ffmpegArgs,options:{quality:'high'}});
      statusEl.textContent=`RUN complete — MP4 ready`;
      if(result?.outputUri) window.open(result.outputUri,'_blank');
    } else {
      const blob=await renderFinal();
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=url; a.download=`ai-video-editor-v0.3-${Date.now()}.webm`;
      a.click();
      setTimeout(()=>URL.revokeObjectURL(url),10000);
      statusEl.textContent='RUN complete — final WebM exported';
    }
    $('#runModal').classList.add('hidden');
  }catch(err){
    statusEl.textContent=`RUN failed: ${err.message}`;
  }finally{btn.disabled=false;}
});

renderFunctions();
renderStack();
buildExecutionPlan();
