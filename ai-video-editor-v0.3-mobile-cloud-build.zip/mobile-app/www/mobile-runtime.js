const NativeRuntime = {
  async render(payload) {
    const plugin = window.Capacitor?.Plugins?.AIVideoRuntime;
    if (!plugin) throw new Error('NATIVE_RUNTIME_UNAVAILABLE');
    return plugin.render(payload);
  },
  async pickVideo() {
    const plugin = window.Capacitor?.Plugins?.AIVideoRuntime;
    if (!plugin) throw new Error('NATIVE_RUNTIME_UNAVAILABLE');
    return plugin.pickVideo();
  }
};
window.AIVideoEditorNative = NativeRuntime;
