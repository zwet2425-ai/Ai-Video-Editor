/**
 * V0.3 Render Worker Adapter
 *
 * Runtime-neutral job lifecycle. The actual FFmpeg implementation can be
 * injected by the host (browser worker, Electron, Node, native bridge).
 *
 * Contract:
 *   submitRenderJob() -> job
 *   runRenderJob(job, executor) -> result
 *
 * executor receives:
 *   { input, output, graph, compiled, reportProgress }
 */

export function createRenderJob({ input, output, graph, compiled }) {
  if (!input) throw new Error('Render input is required.');
  if (!output) throw new Error('Render output is required.');
  if (!graph?.stages) throw new Error('Render graph is required.');

  return Object.freeze({
    id: `render-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
    status: 'queued',
    createdAt: new Date().toISOString(),
    input,
    output,
    graph,
    compiled
  });
}

export async function runRenderJob(job, executor, onUpdate = () => {}) {
  if (!job || job.status !== 'queued') {
    throw new Error('Only queued render jobs can be executed.');
  }
  if (typeof executor !== 'function') {
    throw new Error('Render executor is required.');
  }

  const startedAt = Date.now();
  const reportProgress = (progress, message = '') => {
    const p = Math.max(0, Math.min(100, Number(progress) || 0));
    onUpdate({
      jobId: job.id,
      status: p >= 100 ? 'complete' : 'rendering',
      progress: p,
      message
    });
  };

  onUpdate({ jobId: job.id, status: 'rendering', progress: 0, message: 'Starting render…' });

  try {
    const result = await executor({
      input: job.input,
      output: job.output,
      graph: job.graph,
      compiled: job.compiled,
      reportProgress
    });

    const finished = {
      ...result,
      jobId: job.id,
      status: 'complete',
      progress: 100,
      durationMs: Date.now() - startedAt
    };

    onUpdate(finished);
    return finished;
  } catch (error) {
    const failed = {
      jobId: job.id,
      status: 'failed',
      progress: 0,
      durationMs: Date.now() - startedAt,
      error: normalizeRenderError(error)
    };
    onUpdate(failed);
    throw Object.assign(new Error(failed.error.message), { render: failed });
  }
}

export function normalizeRenderError(error) {
  const message = error?.message || String(error || 'Unknown render error');
  const known = new Set([
    'ENCODER_UNAVAILABLE','OUT_OF_MEMORY','INPUT_DECODE_FAILED','OUTPUT_WRITE_FAILED',
    'FILTER_GRAPH_FAILED','RENDER_FAILED','FFMPEG_PROCESS_FAILED','RUNTIME_COMMAND_FAILED',
    'UNSUPPORTED_STAGE','TRANSITION_REQUIRES_SEGMENTS','TRANSITION_MODE_UNSUPPORTED',
    'BEAT_ANALYSIS_NO_BEATS','BEAT_CUT_TOO_FEW_SEGMENTS','CAPTION_ENGINE_UNAVAILABLE',
    'CAPTION_EMPTY','CAPTION_SUBTITLE_MISSING','CAPTION_PIPELINE_INVALID','CAPTION_BACKEND_MISSING','INVALID_PARAMETER',
    'INVALID_SPEED'
  ]);
  const code = known.has(error?.code) ? error.code :
    /codec|encoder/i.test(message) ? 'ENCODER_UNAVAILABLE' :
    /memory|out of memory/i.test(message) ? 'OUT_OF_MEMORY' :
    /input|decode|demux/i.test(message) ? 'INPUT_DECODE_FAILED' :
    /permission|write|output/i.test(message) ? 'OUTPUT_WRITE_FAILED' :
    /filter|graph/i.test(message) ? 'FILTER_GRAPH_FAILED' :
    'RENDER_FAILED';

  return {
    code,
    message,
    recoverable: !['INPUT_DECODE_FAILED','OUT_OF_MEMORY','UNSUPPORTED_STAGE','CAPTION_ENGINE_UNAVAILABLE','CAPTION_BACKEND_MISSING'].includes(code)
  };
}
