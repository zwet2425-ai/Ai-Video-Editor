/**
 * V0.3 Render Job Store
 * Small in-memory store for UI state. Replaceable with IndexedDB/server queue later.
 */

export class RenderJobStore {
  constructor() {
    this.jobs = new Map();
    this.listeners = new Set();
  }

  add(job) {
    this.jobs.set(job.id, job);
    this.emit();
    return job;
  }

  update(id, patch) {
    const current = this.jobs.get(id);
    if (!current) throw new Error(`Unknown render job: ${id}`);
    const next = Object.freeze({ ...current, ...patch });
    this.jobs.set(id, next);
    this.emit();
    return next;
  }

  get(id) { return this.jobs.get(id); }
  all() { return [...this.jobs.values()]; }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  emit() {
    const snapshot = this.all();
    for (const listener of this.listeners) listener(snapshot);
  }
}
