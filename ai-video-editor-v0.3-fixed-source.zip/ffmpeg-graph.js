/**
 * V0.3 FFmpeg Graph Compiler
 *
 * Compiles the specialized Render Graph into an FFmpeg-oriented
 * filter graph description. The actual worker can execute the args.
 */

export function compileFFmpegGraph(graph) {
  const video = [];
  const audio = [];
  const notes = [];

  for (const stage of graph.stages) {
    const c = stage.config;

    if (stage.id === 'trim') {
      video.push(`trim=start=${c.start}:end=${c.end},setpts=PTS-STARTPTS`);
      audio.push(`atrim=start=${c.start}:end=${c.end},asetpts=PTS-STARTPTS`);
    }

    if (stage.id === 'speed') {
      const factor = c.factor;
      video.push(`setpts=${(1/factor).toFixed(6)}*PTS`);
      addAtempo(audio, factor);
    }

    if (stage.id === 'speed-ramp') {
      notes.push({stage:'speed-ramp', config:c, status:'expression-required'});
    }

    if (stage.id === 'crop') {
      video.push(`crop=${c.width}:${c.height}:${c.x}:${c.y}`);
    }

    if (stage.id === 'resize') {
      video.push(`scale=${c.width}:${c.height}:force_original_aspect_ratio=decrease`);
    }

    if (stage.id === 'zoom-motion') {
      const z = c.amount;
      if (z > 1) video.push(`scale=iw*${z}:ih*${z},crop=iw/${z}:ih/${z}`);
    }

    if (stage.id === 'captions') {
      notes.push({stage:'captions', config:c, status:'requires-generated-subtitle-file'});
    }

    if (stage.id === 'beat-analysis') {
      notes.push({stage:'beat-analysis', config:c, status:'requires-audio-analysis'});
    }

    if (stage.id === 'beat-cut') {
      notes.push({stage:'beat-cut', config:c, status:'requires-segment-map'});
    }

    if (stage.id === 'transition') {
      notes.push({stage:'transition', config:c, status:'requires-multi-input-compositor'});
    }
  }

  return {
    filterComplex: {
      video: video.join(',') || 'null',
      audio: audio.join(',') || 'anull'
    },
    notes,
    maps: ['0:v:0','0:a:0?'],
    encoding: {
      video: ['-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p'],
      audio: ['-c:a','aac','-b:a','192k'],
      container: ['-movflags','+faststart']
    }
  };
}

function addAtempo(filters, speed) {
  let s = speed;
  while (s > 2) { filters.push('atempo=2'); s /= 2; }
  while (s < 0.5) { filters.push('atempo=0.5'); s /= 0.5; }
  filters.push(`atempo=${s.toFixed(6)}`);
}
