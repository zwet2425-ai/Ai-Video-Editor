/**
 * V0.3 Render Engine Adapter
 *
 * Production boundary:
 *   ExecutionPlan -> RenderEngine -> Output
 *
 * This adapter intentionally does not run FFmpeg inside the browser.
 * It generates a deterministic FFmpeg command plan that can be executed
 * by a desktop/backend worker later.
 */

export function createFFmpegPlan({ input, output, plan, media }) {
  const videoFilters = [];
  const audioFilters = [];
  let trimStart = null;
  let trimEnd = null;
  let setPts = null;

  for (const step of plan) {
    const p = step.params || {};

    switch (step.id) {
      case 'trim':
        trimStart = timeToSeconds(p.start);
        trimEnd = timeToSeconds(p.end);
        break;

      case 'speed': {
        const speed = Number(p.speed);
        if (Number.isFinite(speed) && speed > 0) {
          videoFilters.push(`setpts=${(1 / speed).toFixed(6)}*PTS`);
          buildAtempo(audioFilters, speed);
        }
        break;
      }

      case 'crop':
        videoFilters.push(
          `crop=${safeNum(p.width)}:${safeNum(p.height)}:${safeNum(p.x)}:${safeNum(p.y)}`
        );
        break;

      case 'resize':
        videoFilters.push(
          `scale=${safeNum(p.width)}:${safeNum(p.height)}:force_original_aspect_ratio=decrease`
        );
        break;

      case 'zoomMotion': {
        const amount = Math.max(1, Math.min(4, Number(p.amount) || 1));
        // Stable V0.3 zoom foundation. More advanced motion expressions can replace this.
        if (amount > 1) {
          videoFilters.push(
            `scale=iw*${amount}:ih*${amount},crop=iw/${amount}:ih/${amount}`
          );
        }
        break;
      }

      case 'speedRamp':
        // Keep ramp as an explicit planner node. Full expression generation belongs
        // to the production renderer implementation.
        setPts = 'speed-ramp';
        break;

      case 'transition':
        // Transition requires multi-input composition and will be handled by the
        // compositor layer once split segments are materialized.
        break;

      case 'split':
      case 'beatSync':
      case 'beatCut':
      case 'caption':
        // Planner nodes reserved for their specialized render modules.
        break;
    }
  }

  const vf = videoFilters.length ? videoFilters.join(',') : null;
  const args = ['-y', '-i', input];

  if (trimStart !== null) args.push('-ss', String(trimStart));
  if (trimEnd !== null && trimStart !== null) {
    args.push('-t', String(Math.max(0, trimEnd - trimStart)));
  }

  if (vf) args.push('-vf', vf);

  args.push(
    '-map', '0:v:0',
    '-map', '0:a:0?',
    '-c:v', 'libx264',
    '-preset', 'medium',
    '-crf', '18',
    '-pix_fmt', 'yuv420p',
    '-c:a', 'aac',
    '-b:a', '192k',
    '-movflags', '+faststart',
    output
  );

  return {
    engine: 'ffmpeg',
    version: 'v0.3',
    input,
    output,
    args,
    videoFilters,
    audioFilters,
    unresolvedNodes: plan
      .filter(x => ['transition','split','beatSync','beatCut','caption','speedRamp'].includes(x.id))
      .map(x => x.id)
  };
}

function buildAtempo(filters, speed) {
  // FFmpeg atempo supports 0.5–2.0 per filter. Chain when outside that range.
  let s = speed;
  while (s > 2) {
    filters.push('atempo=2');
    s /= 2;
  }
  while (s < 0.5) {
    filters.push('atempo=0.5');
    s /= 0.5;
  }
  filters.push(`atempo=${s.toFixed(6)}`);
}

function safeNum(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) throw new Error(`Invalid numeric render parameter: ${v}`);
  return Math.round(n);
}

function timeToSeconds(v) {
  const parts = String(v).split(':').map(Number);
  if (parts.some(Number.isNaN)) throw new Error(`Invalid time: ${v}`);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return Number(parts[0]) || 0;
}
