#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { buildRenderGraph } from './render-graph.js';
import { compileFFmpegGraph } from './ffmpeg-graph.js';
import { createRenderJob, runRenderJob } from './render-worker.js';
import { createNodeFFmpegExecutor } from './ffmpeg-runtime-node.js';

function usage() {
  console.log(`AI Video Editor V0.3 — actual FFmpeg worker

Usage:
  node render-cli.js <input> <output> [plan.json]

plan.json format:
  [{"id":"trim","params":{"start":"00:00:00","end":"00:00:10"}}]

If omitted, a safe no-op plan is used only for runtime smoke testing.
`);
}

const [, , input, output, planFile] = process.argv;
if (!input || !output) { usage(); process.exit(2); }

const plan = planFile
  ? JSON.parse(await readFile(planFile,'utf8'))
  : [{step:1,id:'resize',name:'RESIZE',params:{width:1280,height:720,lock:true}}];

const graph = buildRenderGraph({input, output, plan, media:{}});
const compiled = compileFFmpegGraph(graph);
const job = createRenderJob({input,output,graph,compiled});
const executor = createNodeFFmpegExecutor();

await runRenderJob(job, executor, update => {
  process.stdout.write(`[${update.status}] ${update.progress.toFixed?.(1) ?? update.progress}% ${update.message || ''}\n`);
}).catch(err => {
  console.error(JSON.stringify(err.render || {message:err.message},null,2));
  process.exit(1);
});
