# V0.3 Mobile Build Status

## Ready
- Existing V0.3 render core preserved.
- Capacitor 7 shell.
- AIVideoRuntime native plugin.
- Android video picker.
- Native FFmpeg bridge.
- MediaStore output publishing on Android 10+.
- Automated native plugin application script.
- Pinned maintained FFmpegKit Full dependency.

## Remaining on a machine with Android SDK
1. `cd mobile-app && npm install`
2. `npm run android:prepare`
3. `npm run android:apply-native`
4. `npm run android:build`
5. Install `android/app/build/outputs/apk/debug/app-debug.apk` on a real Android phone.

## Important
The current execution environment timed out while fetching npm packages, and it has no Android SDK/Gradle installation. Therefore an APK binary cannot truthfully be claimed as built here.
