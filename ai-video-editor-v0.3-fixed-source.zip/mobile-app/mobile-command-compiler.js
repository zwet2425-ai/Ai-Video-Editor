// Mobile adapter compiler. The V0.3 desktop Render Core remains authoritative;
// this module only converts the already-planned actions into a conservative
// native FFmpeg argument list for the Android adapter.
export function compileMobileFFmpegArgs({ executionPlan, captions = [] }) {
  const filters=[];
  const audio=[];
  const unsupported=[];
  for (const step of executionPlan || []) {
    const p=step.params || {};
    switch(step.id) {
      case 'trim':
        filters.push(`trim=start=${numTime(p.start)}:end=${numTime(p.end)},setpts=PTS-STARTPTS`);
        audio.push(`atrim=start=${numTime(p.start)}:end=${numTime(p.end)},asetpts=PTS-STARTPTS`);
        break;
      case 'speed': {
        const f=Number(p.speed||1); if(!(f>0)) throw new Error('INVALID_SPEED');
        filters.push(`setpts=${(1/f).toFixed(6)}*PTS`); audio.push(...atempo(f)); break;
      }
      case 'crop': filters.push(`crop=${Number(p.width)}:${Number(p.height)}:${Number(p.x||0)}:${Number(p.y||0)}`); break;
      case 'resize': filters.push(`scale=${Number(p.width)}:${Number(p.height)}:force_original_aspect_ratio=decrease`); break;
      case 'zoomMotion': {
        const z=Math.max(1,Math.min(4,Number(p.amount||1))); if(z>1) filters.push(`scale=iw*${z}:ih*${z},crop=iw/${z}:ih/${z}`); break;
      }
      case 'caption':
        if(captions.length) unsupported.push('caption-burn-in requires generated ASS path from caption store');
        break;
      case 'split': unsupported.push('split materialization is handled by the full V0.3 Render Core adapter'); break;
      case 'transition': unsupported.push('multi-input transition is handled by the full V0.3 Render Core adapter'); break;
      case 'beatSync': unsupported.push('beat analysis must run before native graph compilation'); break;
      case 'beatCut': unsupported.push('beat cut segment map must run before native graph compilation'); break;
      case 'speedRamp': unsupported.push('speed-ramp expression compiler must run before native graph compilation'); break;
      default: unsupported.push(step.id);
    }
  }
  if(unsupported.length) throw new Error('MOBILE_GRAPH_STAGE_UNSUPPORTED:' + unsupported.join('|'));

  // A plain export must work even when no editor function is enabled.
  // Use optional audio mapping so videos without an audio track still export.
  if(!filters.length && !audio.length){
    return ['-y','-i','{INPUT}','-map','0:v:0','-map','0:a:0?','-c:v','mpeg4','-preset','veryfast','-q:v','3','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','{OUTPUT}'];
  }

  const vf=filters.join(',') || 'null';
  const af=audio.join(',') || 'anull';
  return ['-y','-i','{INPUT}','-filter_complex',`[0:v]${vf}[v];[0:a]${af}[a]`,'-map','[v]','-map','[a]','-c:v','mpeg4','-preset','veryfast','-q:v','3','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','{OUTPUT}'];
}
function numTime(v){
  if(typeof v==='number') return v;
  const p=String(v||0).split(':').map(Number); if(p.length===3) return p[0]*3600+p[1]*60+p[2]; if(p.length===2) return p[0]*60+p[1]; return Number(p[0])||0;
}
function atempo(f){ const out=[]; let s=f; while(s>2){out.push('atempo=2');s/=2;} while(s<.5){out.push('atempo=.5');s/=.5;} out.push(`atempo=${s.toFixed(6)}`); return out; }
