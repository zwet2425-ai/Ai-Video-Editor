# AI Video Editor V0.3 — Mobile App Shell

This folder is an **additive Android shell** around the existing V0.3 editor.
It does not replace or move the V0.3 Render Core.

## Preserved core

The parent project remains the source of truth for:

- Function Registry
- Action Store
- Validator
- Execution Planner
- Render Graph
- FFmpeg Graph Compiler
- Render Worker
- Manual SRT/VTT caption pipeline
- Browser Canvas/WebM fallback

## Mobile boundary

`www/` contains the existing UI as a mobile web surface.
`www/mobile-runtime.js` exposes one native bridge:

- `AIVideoRuntime.pickVideo()`
- `AIVideoRuntime.render(payload)`

The Android implementation belongs under `android-runtime/` and must call the
existing Render Worker contract. It must not implement a second editor.

## Current state

- Mobile web shell: READY
- Capacitor configuration: READY
- Native plugin contract: READY
- Native Android FFmpeg implementation: PREPARED / APPLY SCRIPT INCLUDED
- APK build: BLOCKED HERE because Android SDK/Gradle dependency setup is unavailable

## Why this separation is safe

The native runtime is an adapter. If Android FFmpeg work changes later, the
editor state and rendering graph do not need to be redesigned.

## Next implementation stage

1. Generate the Android project with Capacitor.
2. Implement `AIVideoRuntime` native plugin.
3. Connect Android content URIs to the Render Worker.
4. Bundle/bridge an Android-safe FFmpeg runtime.
5. Return a new MP4 URI after every RUN.
6. Build and install the APK on a real Android phone.

## Native Android runtime stage

The project now contains an additive `android-runtime/` adapter and a mobile FFmpeg command compiler. The Android plugin uses the maintained FFmpegKit Android artifact and exposes `pickVideo()` + `render()` without moving Registry/Action Store/Planner/Render Graph into native code.

The native command adapter intentionally rejects graph stages it cannot safely compile yet (`MOBILE_GRAPH_STAGE_UNSUPPORTED`) instead of silently dropping them. The full V0.3 Render Core remains the source of truth for the complete graph.

### Local Android setup

1. Install Android Studio + Android SDK.
2. From `mobile-app/`, run `npm install`.
3. Run `npm run android:prepare` to generate/sync the Capacitor Android project.
4. Apply `android-runtime/AIVideoRuntimePlugin.java`, dependency snippet, provider XML and plugin registration as documented in `android-runtime/README.md`.
5. Open with `npm run open:android`, build/install on a real Android device.

Capacitor requires Android Studio and an Android SDK for native Android development. See the official Capacitor Android setup documentation.


## Build-ready native stage (mobile.2)

After `npm run android:prepare`, run `npm run android:apply-native`. This copies the native plugin, FileProvider paths, registers `AIVideoRuntimePlugin` in `MainActivity`, and adds the maintained FFmpegKit Full dependency. Then run `npm run android:build`.

The mobile compiler intentionally uses the LGPL-safe `mpeg4` encoder rather than `libx264`; the latter belongs to GPL builds. The full artifact provides libass subtitle support. The native render result is published to Android MediaStore under `Movies/AI Video Editor` on Android 10+ so every RUN produces a new device-visible MP4.


## Phone-only cloud APK build

A GitHub Actions workflow is included at `.github/workflows/android-debug.yml`. It can build the debug APK in the cloud, so the development machine does not need Android Studio. After the workflow completes, download the `ai-video-editor-v0.3-debug-apk` artifact and install it on an Android device (allowing installation from the source used to download it, if Android asks).

See the project-root `APP_IDENTITY.md` for the safe app-name/package-ID separation.
