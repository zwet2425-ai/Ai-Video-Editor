/*
 * Android runtime boundary.
 *
 * The V0.3 browser editor remains the source of truth for Registry,
 * Action Store, Planner and Render Graph. This adapter only defines the
 * native boundary; it does not duplicate editor state.
 */

export const NativeRuntime = {
  async render(payload) {
    if (!window.Capacitor?.Plugins?.AIVideoRuntime) {
      throw new Error('NATIVE_RUNTIME_UNAVAILABLE');
    }
    return window.Capacitor.Plugins.AIVideoRuntime.render(payload);
  },

  async pickVideo() {
    if (!window.Capacitor?.Plugins?.AIVideoRuntime) {
      throw new Error('NATIVE_RUNTIME_UNAVAILABLE');
    }
    return window.Capacitor.Plugins.AIVideoRuntime.pickVideo();
  }
};

window.AIVideoEditorNative = NativeRuntime;
