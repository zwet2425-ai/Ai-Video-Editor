# Android Native Runtime — V0.3 additive adapter

This layer does **not** recreate the editor. It only bridges the existing V0.3 Render Graph/FFmpeg command plan to Android.

## Runtime

Uses the community-maintained FFmpegKit Android artifact:

`dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7`

The original FFmpegKit line was retired; this maintained Android fork keeps the same package/API and current Android build support.

## Native plugin

Copy `AIVideoRuntimePlugin.java` into the generated Capacitor Android app under:

`android/app/src/main/java/com/aivideoeditor/v03/runtime/`

Register the plugin in the Capacitor Android bridge using the generated app's plugin registration mechanism.

Add `build.gradle.snippet` dependency, copy `file_paths.xml` to `android/app/src/main/res/xml/`, and merge `AndroidManifest.additions.xml` inside `<application>`.

## Contract

- `pickVideo()` → Storage Access Framework video URI
- `render({inputUri, ffmpegArgs})` → new MP4 URI

`ffmpegArgs` must be produced by the existing V0.3 graph compiler. The Android adapter only resolves `{INPUT}` and `{OUTPUT}`.
