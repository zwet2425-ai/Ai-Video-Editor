# AIVideoRuntime Android plugin contract

This is intentionally an adapter boundary, not a second editor architecture.

## Required methods

### `pickVideo()`
Returns:
```json
{"uri":"content://...","name":"input.mp4","mimeType":"video/mp4"}
```

### `render(payload)`
Input:
```json
{
  "inputUri":"content://...",
  "outputName":"aive-render-<timestamp>.mp4",
  "executionPlan": [],
  "renderGraph": {},
  "options": {"quality":"high"}
}
```

Output:
```json
{
  "status":"complete",
  "outputUri":"content://...",
  "mimeType":"video/mp4"
}
```

## Native implementation target

The plugin should execute the existing FFmpeg Render Worker contract through an
Android-safe FFmpeg runtime. It must not recreate Registry, Action Store,
Execution Planner, or Render Graph.

Until this plugin exists, the mobile shell can still use the browser Canvas/WebM
fallback. The native MP4 path must report `NATIVE_RUNTIME_UNAVAILABLE` rather
than silently falling back when the user explicitly requests native render.
