#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [ ! -d android ]; then
  echo "ERROR: android/ does not exist. Run npm run android:prepare first."
  exit 2
fi
APP=android/app
SRC="$APP/src/main/java/com/aivideoeditor/v03/runtime"
mkdir -p "$SRC" "$APP/src/main/res/xml"
cp android-runtime/AIVideoRuntimePlugin.java "$SRC/AIVideoRuntimePlugin.java"
cp android-runtime/file_paths.xml "$APP/src/main/res/xml/file_paths.xml"
python3 - "$APP/src/main/AndroidManifest.xml" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
provider='''\n        <provider\n            android:name="androidx.core.content.FileProvider"\n            android:authorities="${applicationId}.fileprovider"\n            android:exported="false"\n            android:grantUriPermissions="true">\n            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths" />\n        </provider>'''
if 'androidx.core.content.FileProvider' not in s:
    s=s.replace('</application>', provider+'\n    </application>')
p.write_text(s)
PY
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
d="implementation 'dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9'"
if d not in s:
    marker='dependencies {'
    if marker in s: s=s.replace(marker, marker+'\n    '+d, 1)
p.write_text(s)
PY
MAIN=$(find android/app/src/main/java -name MainActivity.java | head -1 || true)
if [ -n "$MAIN" ]; then
  python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
imp='import com.aivideoeditor.v03.runtime.AIVideoRuntimePlugin;\n'
if imp not in s:
    pkg=s.find('\n', s.find('package '))+1
    s=s[:pkg]+imp+s[pkg:]
if 'registerPlugin(AIVideoRuntimePlugin.class)' not in s:
    if 'onCreate(' in s:
        s=s.replace('{\n', '{\n        registerPlugin(AIVideoRuntimePlugin.class);\n',1)
    else:
        s=s.replace('public class MainActivity extends BridgeActivity {','public class MainActivity extends BridgeActivity {\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        super.onCreate(savedInstanceState);\n        registerPlugin(AIVideoRuntimePlugin.class);\n    }')
p.write_text(s)
PY
else
  echo 'WARNING: MainActivity.java not found; register plugin manually in generated MainActivity.'
fi
printf '\nNative runtime applied. Next: ./gradlew :app:assembleDebug\n'
