#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm install
if [ ! -d android ]; then
  npx cap add android
else
  npx cap sync android
fi
printf '\nAndroid project is ready. Apply native runtime with: npm run android:apply-native\nThen build with: npm run android:build\n'
