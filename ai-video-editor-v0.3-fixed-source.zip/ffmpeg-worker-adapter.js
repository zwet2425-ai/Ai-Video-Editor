/**
 * V0.3 FFmpeg executor adapter.
 *
 * Host integration point. Pass an object implementing:
 *   ffmpeg.run(args)
 *   ffmpeg.on('progress', callback)   [optional]
 *
 * The adapter deliberately does not assume a particular FFmpeg WASM package.
 */

export function createFFmpegExecutor(ffmpeg, buildArgs) {
  if (!ffmpeg || typeof ffmpeg.run !== 'function') {
    throw new Error('FFmpeg runtime with run(args) is required.');
  }

  return async ({ input, output, compiled, reportProgress }) => {
    const args = buildArgs({ input, output, compiled });

    if (!Array.isArray(args) || !args.length) {
      throw new Error('FFmpeg argument builder returned an empty command.');
    }

    const progressHandler = data => {
      const p = parseFFmpegProgress(data);
      if (p != null) reportProgress(p, 'FFmpeg rendering…');
    };

    if (typeof ffmpeg.on === 'function') {
      try { ffmpeg.on('progress', progressHandler); } catch (_) {}
    }

    try {
      await ffmpeg.run(args);
      return { output, engine: 'ffmpeg' };
    } finally {
      if (typeof ffmpeg.off === 'function') {
        try { ffmpeg.off('progress', progressHandler); } catch (_) {}
      }
    }
  };
}

function parseFFmpegProgress(data) {
  if (typeof data === 'number') return data <= 1 ? data * 100 : data;
  if (!data || typeof data !== 'object') return null;
  if (Number.isFinite(data.progress)) return data.progress <= 1 ? data.progress * 100 : data.progress;
  if (Number.isFinite(data.ratio)) return data.ratio * 100;
  return null;
}
