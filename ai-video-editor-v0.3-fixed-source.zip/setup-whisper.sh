#!/usr/bin/env bash
set -euo pipefail
PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -m pip install -r "$(dirname "$0")/requirements-whisper.txt"
echo "Whisper backend installed. Set WHISPER_MODEL if you want another model (default: small)."
