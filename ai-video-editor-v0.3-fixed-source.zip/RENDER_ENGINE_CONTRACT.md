# V0.3 Render Engine Contract

The existing UI/state layer remains unchanged.

## Engine boundary

```text
Action Store
   ↓
Validator
   ↓
Execution Planner
   ↓
RenderEngineAdapter
   ↓
FFmpeg / WebCodecs Worker
   ↓
Output
```

## Rules

1. The renderer receives an immutable `ExecutionPlan`.
2. The renderer never edits the original source file.
3. Every RUN creates a new output.
4. Preview and final rendering remain separate paths.
5. Unsupported functions must be reported as `unresolvedNodes`; they must not silently disappear.
6. Function Registry IDs are the stable interface between UI and renderer.
7. UI order is never assumed to be render order.
8. The adapter can later be moved to a Web Worker, Electron process, Node backend, or native service without changing the Action Store.

## Current production-ready foundation

- TRIM → `-ss` / duration
- SPEED → `setpts` + chained `atempo`
- CROP → `crop`
- RESIZE → `scale`
- ZOOM/MOTION → stable scale/crop foundation
- MP4/H.264/AAC output defaults
- fast-start MP4

## Next specialized modules

- SPLIT segment materialization
- TRANSITION multi-input compositor
- BEAT SYNC analysis
- BEAT CUT segment planner
- SPEED RAMP time-varying expressions
- AUTO CAPTION transcription + subtitle/burn-in pipeline


## Specialized render graph

All registered functions now map to explicit render stages:

- SPLIT → segment
- TRIM → temporal
- SPEED → temporal
- SPEED RAMP → temporal
- CROP → geometry
- RESIZE → geometry
- ZOOM / MOTION → motion
- TRANSITION → composite
- BEAT SYNC → audio analysis + temporal map
- BEAT CUT → audio analysis + segmentation
- AUTO CAPTION → transcription + overlay

The graph is deterministic and can be consumed by FFmpeg/WebCodecs workers.


## Worker execution boundary

The render graph is now separated from runtime execution:

```text
Execution Plan
  ↓
Render Graph
  ↓
FFmpeg Graph Compiler
  ↓
Render Job
  ↓
Render Worker Adapter
  ↓
FFmpeg / WebCodecs / Native runtime
  ↓
New Output
```

`render-worker.js` owns job lifecycle and normalized errors.
`ffmpeg-worker-adapter.js` connects an actual FFmpeg runtime without coupling the UI to a specific FFmpeg package.
`render-job-store.js` provides observable render status for future progress UI.

Render errors are normalized into:
- `ENCODER_UNAVAILABLE`
- `OUT_OF_MEMORY`
- `INPUT_DECODE_FAILED`
- `OUTPUT_WRITE_FAILED`
- `FILTER_GRAPH_FAILED`
- `RENDER_FAILED`


## V0.3 actual runtime continuation

The renderer now has a concrete system-FFmpeg host implementation:
`Render Worker → Node FFmpeg Runtime → ffmpeg/ffprobe → verified new MP4`.

The runtime is deliberately separate from the browser UI, so the locked state/preview architecture remains intact.
