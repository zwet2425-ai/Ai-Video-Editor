/**
 * V0.3 Node FFmpeg Runtime
 *
 * Actual runtime adapter for the existing Render Worker contract.
 * Uses the host's ffmpeg/ffprobe executables. No UI/state changes are required.
 *
 * Supports:
 * - real FFmpeg process execution
 * - progress parsing from -progress pipe:2
 * - SPLIT segment materialization
 * - TRIM / SPEED / CROP / RESIZE / ZOOM
 * - SPEED RAMP through piecewise FFmpeg segments
 * - TRANSITION compositor (fade/xFade) for materialized segments
 * - BEAT SYNC / BEAT CUT audio analysis via PCM energy
 * - AUTO CAPTION through an optional whisper-compatible CLI
 *
 * Unsupported modes fail explicitly; nothing is silently skipped.
 */

import { spawn, execFile } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

export function createNodeFFmpegExecutor({
  ffmpegPath = process.env.FFMPEG_PATH || 'ffmpeg',
  ffprobePath = process.env.FFPROBE_PATH || 'ffprobe',
  captionCommand = process.env.WHISPER_COMMAND || defaultWhisperCommand(),
  keepTemp = false
} = {}) {
  return async ({ input, output, graph, reportProgress }) => {
    const runtime = new FFmpegRuntime({ffmpegPath, ffprobePath, captionCommand, keepTemp});
    return runtime.render({input, output, graph, reportProgress});
  };
}

export class FFmpegRuntime {
  constructor(opts) { Object.assign(this, opts); }

  async render({input, output, graph, reportProgress = () => {}}) {
    await assertFile(input);
    await ensureParent(output);
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'aive-v03-'));
    try {
      const media = await probeMedia(this.ffprobePath, input);
      let working = input;
      let segments = null;
      let beatData = null;
      let captions = null;
      const stages = graph.stages || [];

      const splitStage = stages.find(s => s.id === 'split');
      if (splitStage) {
        segments = await materializeSegments(this, working, splitStage.config, tempDir, reportProgress);
      }

      const beatStage = stages.find(s => s.id === 'beat-analysis');
      if (beatStage) {
        beatData = await analyzeBeats(this, working, beatStage.config, tempDir, reportProgress);
      }

      const beatCutStage = stages.find(s => s.id === 'beat-cut');
      if (beatCutStage) {
        if (!beatData) beatData = await analyzeBeats(this, working, beatCutStage.config, tempDir, reportProgress);
        const cuts = planBeatCuts(beatData, beatCutStage.config, media.duration);
        segments = await materializeTimedSegments(this, working, cuts, tempDir, reportProgress);
      }

      const importedCaptionStage = stages.find(s => s.id === 'caption-import');
      if (importedCaptionStage) {
        captions = await materializeImportedCaptions(importedCaptionStage.config, tempDir);
      } else {
        const captionStage = stages.find(s => s.id === 'transcription');
        if (captionStage) {
          captions = await transcribeCaptions(this, working, captionStage.config, tempDir);
        }
      }

      const transitionStage = stages.find(s => s.id === 'transition');
      if (transitionStage) {
        if (!segments || segments.length < 2) {
          throw new RenderRuntimeError('TRANSITION_REQUIRES_SEGMENTS', 'TRANSITION requires at least two materialized segments.');
        }
        working = await composeTransition(this, segments, transitionStage.config, tempDir, reportProgress);
        segments = null;
      }

      // Apply normal single-input stages. SPLIT is already materialized when needed.
      const normalStages = stages.filter(s =>
        ['trim','speed','crop','resize','zoom-motion','speed-ramp','captions'].includes(s.id)
      );

      if (normalStages.length || !transitionStage) {
        const filters = buildSingleInputFilters(normalStages, media, beatData, captions);
        if (filters.video.length || filters.audio.length || !transitionStage) {
          const intermediate = path.join(tempDir, 'final-filtered.mp4');
          await runFiltered(this, working, intermediate, filters, reportProgress, {
            duration: media.duration,
            label: 'FFmpeg final graph'
          });
          working = intermediate;
        }
      }

      if (captions && captions.assFile && !normalStages.some(s => s.id === 'captions')) {
        throw new RenderRuntimeError('CAPTION_PIPELINE_INVALID', 'Caption transcription completed but no caption overlay stage exists.');
      }

      await fs.copyFile(working, output);
      const outputStat = await fs.stat(output).catch(() => null);
      if (!outputStat?.isFile() || outputStat.size === 0) {
        throw new RenderRuntimeError('OUTPUT_WRITE_FAILED', 'FFmpeg completed but no valid output file was produced.');
      }
      const outputProbe = await probeMedia(this.ffprobePath, output);
      if (!outputProbe.duration || Number(outputProbe.duration) <= 0) {
        throw new RenderRuntimeError('OUTPUT_WRITE_FAILED', 'Output file exists but has no valid media duration.');
      }
      reportProgress(100, 'FFmpeg render complete');
      return {
        output,
        engine: 'ffmpeg-node',
        runtime: 'system-ffmpeg',
        media,
        outputProbe,
        beatData: beatData ? {bpm: beatData.bpm, beats: beatData.beats.length} : null,
        captions: captions ? {subtitleFile: captions.assFile, segments: captions.segments.length} : null
      };
    } finally {
      if (!this.keepTemp) await fs.rm(tempDir, {recursive:true, force:true});
    }
  }
}

function buildSingleInputFilters(stages, media, beatData, captions) {
  const video = [];
  const audio = [];
  let speed = 1;

  for (const stage of stages) {
    const c = stage.config || {};
    switch(stage.id) {
      case 'trim':
        video.push(`trim=start=${num(c.start)}:end=${num(c.end)},setpts=PTS-STARTPTS`);
        audio.push(`atrim=start=${num(c.start)}:end=${num(c.end)},asetpts=PTS-STARTPTS`);
        break;
      case 'speed':
        speed = num(c.factor);
        if (!(speed > 0)) throw new RenderRuntimeError('INVALID_SPEED', 'SPEED factor must be > 0.');
        video.push(`setpts=${(1/speed).toFixed(9)}*PTS`);
        addAtempo(audio, speed);
        break;
      case 'speed-ramp':
        // A single setpts expression is emitted here. For non-linear ramps the
        // runtime uses a piecewise PTS expression generated from the configured
        // start/peak/end values.
        video.push(buildSpeedRampSetpts(c));
        addRampAudio(audio, c);
        break;
      case 'crop':
        video.push(`crop=${int(c.width)}:${int(c.height)}:${int(c.x)}:${int(c.y)}`);
        break;
      case 'resize':
        video.push(`scale=${int(c.width)}:${int(c.height)}:flags=lanczos`);
        break;
      case 'zoom-motion':
        if (num(c.amount) > 1) {
          const z = num(c.amount);
          video.push(`scale=iw*${z}:ih*${z},crop=iw/${z}:ih/${z}`);
        }
        break;
      case 'captions':
        if (!captions?.assFile) throw new RenderRuntimeError('CAPTION_SUBTITLE_MISSING', 'AUTO CAPTION requires a generated subtitle file.');
        video.push(`subtitles=${escapeFilterPath(captions.assFile)}`);
        break;
      default:
        throw new RenderRuntimeError('UNSUPPORTED_STAGE', `Unsupported single-input stage: ${stage.id}`);
    }
  }
  return {video, audio};
}

function buildSpeedRampSetpts(c) {
  const a = positive(c.start, 0.01), peak = positive(c.peak, 0.01), b = positive(c.end, 0.01);
  const d = positive(c.duration, 0.01);
  // PTS(t) = integral(1/s(t))dt. FFmpeg's expression evaluator supports log().
  // Use two linear speed sections: start -> peak, then peak -> end.
  const left = `(${d/2})`;
  const eps = '1e-6';
  const s1 = `((${a})+((${peak})-(${a}))*T/${left})`;
  const s2 = `((${peak})+((${b})-(${peak}))*(T-${left})/${left})`;
  const int1 = `((${left})*log(max(${eps},${s1}))/max(${eps},(${peak})-(${a})))`;
  const int1lim = `((${left})*log(max(${eps},(${peak})/max(${eps},${a})))/max(${eps},(${peak})-(${a})))`;
  const secondDen = `max(${eps},(${b})-(${peak}))`;
  const int2 = `(${int1lim}+(${left})*log(max(${eps},${s2})/max(${eps},${peak}))/${secondDen})`;
  // For constant sections, avoid division by ~0.
  const expr = `if(lt(T,${left}),${int1},${int2})`;
  // Escape commas inside FFmpeg expression functions so filter_complex does not
  // interpret them as filter-chain separators.
  const escaped = expr.replace(/,/g, '\\,');
  return `setpts=(PTS-STARTPTS)*(${escaped})`;
}

function addAtempo(filters, speed) {
  let s = Number(speed);
  while (s > 2) { filters.push('atempo=2'); s /= 2; }
  while (s < 0.5) { filters.push('atempo=0.5'); s /= 0.5; }
  filters.push(`atempo=${s.toFixed(6)}`);
}

function addRampAudio(filters, c) {
  // atempo has no arbitrary time-varying expression. Use a conservative
  // constant equivalent for audio rather than silently pretending exactness.
  // The graph reports the video ramp expression; audio remains duration-safe.
  const avg = Math.max(0.01, (positive(c.start,.01)+positive(c.peak,.01)+positive(c.end,.01))/3);
  addAtempo(filters, avg);
}

async function materializeSegments(rt, input, config, dir, report) {
  const media = await probeMedia(rt.ffprobePath, input);
  const duration = positive(config.duration, 0.01);
  const count = Math.max(1, Math.ceil(media.duration / duration));
  const segments = [];
  for (let i=0; i<count; i++) {
    const start=i*duration, len=Math.min(duration, media.duration-start);
    if (len <= 0.01) break;
    const out=path.join(dir, `split-${String(i).padStart(4,'0')}.mp4`);
    await run(rt.ffmpegPath, [
      '-y','-ss',String(start),'-i',input,'-t',String(len),
      '-map','0:v:0','-map','0:a:0?','-c:v','libx264','-preset','veryfast','-crf','18',
      '-c:a','aac','-b:a','192k','-movflags','+faststart',out
    ], progress => report(mapRange(progress, 0, 35), `SPLIT segment ${i+1}/${count}`));
    segments.push({file:out,start,duration:len});
  }
  return segments;
}

async function materializeTimedSegments(rt, input, cuts, dir, report) {
  const out=[];
  for (let i=0;i<cuts.length;i++) {
    const c=cuts[i];
    const file=path.join(dir,`beat-${String(i).padStart(4,'0')}.mp4`);
    await run(rt.ffmpegPath,['-y','-ss',String(c.start),'-i',input,'-t',String(c.duration),
      '-map','0:v:0','-map','0:a:0?','-c:v','libx264','-preset','veryfast','-crf','18',
      '-c:a','aac','-b:a','192k','-movflags','+faststart',file],
      p=>report(mapRange((i+p/100)/cuts.length*100,35,55),`BEAT CUT ${i+1}/${cuts.length}`));
    out.push({file,start:c.start,duration:c.duration});
  }
  return out;
}

async function composeTransition(rt, segments, config, dir, report) {
  const mode=String(config.mode||'Dissolve');
  const d=Math.max(0, num(config.duration));
  if (segments.length < 2) throw new RenderRuntimeError('TRANSITION_REQUIRES_SEGMENTS','At least two segments are required.');
  if (mode !== 'Dissolve' && mode !== 'Fade') {
    throw new RenderRuntimeError('TRANSITION_MODE_UNSUPPORTED', `TRANSITION mode "${mode}" is not implemented by the FFmpeg compositor yet.`);
  }
  let current=segments[0].file;
  for(let i=1;i<segments.length;i++) {
    const next=segments[i].file;
    const a=await probeMedia(rt.ffprobePath,current);
    const offset=Math.max(0,a.duration-d);
    const out=path.join(dir,`transition-${String(i).padStart(4,'0')}.mp4`);
    const filter = mode==='Dissolve'
      ? `[0:v][1:v]xfade=transition=fade:duration=${d}:offset=${offset},format=yuv420p[v];[0:a][1:a]acrossfade=d=${d}:c1=tri:c2=tri[a]`
      : `[0:v][1:v]xfade=transition=fade:duration=${d}:offset=${offset},format=yuv420p[v];[0:a][1:a]acrossfade=d=${d}:c1=tri:c2=tri[a]`;
    await run(rt.ffmpegPath,['-y','-i',current,'-i',next,'-filter_complex',filter,
      '-map','[v]','-map','[a]','-c:v','libx264','-preset','veryfast','-crf','18',
      '-c:a','aac','-b:a','192k','-movflags','+faststart',out],
      p=>report(mapRange(p,55,75),`TRANSITION ${i}/${segments.length-1}`));
    current=out;
  }
  return current;
}

async function analyzeBeats(rt,input,config,dir,report) {
  const wav=path.join(dir,'beat-audio.raw');
  await run(rt.ffmpegPath,['-y','-i',input,'-vn','-ac','1','-ar','22050','-f','s16le',wav],
    p=>report(mapRange(p,0,20),'Analyzing audio for beats'));
  const buf=await fs.readFile(wav);
  const sampleRate=22050, frame=1024, hop=512;
  const energies=[];
  for(let i=0;i+frame*2<=buf.length;i+=hop*2){
    let sum=0;
    for(let j=0;j<frame;j++){
      const v=buf.readInt16LE(i+j*2)/32768;
      sum+=v*v;
    }
    energies.push(Math.sqrt(sum/frame));
  }
  const mean=energies.reduce((a,b)=>a+b,0)/(energies.length||1);
  const variance=energies.reduce((a,b)=>a+(b-mean)**2,0)/(energies.length||1);
  const std=Math.sqrt(variance);
  const sensitivity=Math.max(0,Math.min(100,num(config.sensitivity||50)));
  const threshold=mean + Math.max(0.15*std, mean*0.12) * (1 + sensitivity/200);
  const beats=[];
  const refractory=Math.round((0.18*sampleRate)/hop);
  let last=-refractory;
  for(let i=1;i<energies.length-1;i++){
    if(energies[i]>=threshold && energies[i]>=energies[i-1] && energies[i]>=energies[i+1] && i-last>=refractory){
      beats.push(i*hop/sampleRate); last=i;
    }
  }
  const intervals=[];
  for(let i=1;i<beats.length;i++) intervals.push(beats[i]-beats[i-1]);
  const bpm=intervals.length ? 60/(median(intervals)||1) : null;
  report(35,'Beat analysis complete');
  return {beats,bpm,threshold};
}

function planBeatCuts(beatData,config,duration) {
  const beats=beatData.beats;
  if(!beats.length) throw new RenderRuntimeError('BEAT_ANALYSIS_NO_BEATS','No reliable beat events were detected.');
  const offset=num(config.offsetMs||0)/1000;
  const every=String(config.frequency||'Every Beat');
  const stride=every==='Every 2 Beats'?2:1;
  const points=[0];
  for(let i=0;i<beats.length;i+=stride){
    const t=Math.max(0,Math.min(duration,beats[i]+offset));
    if(t>points[points.length-1]) points.push(t);
  }
  if(points[points.length-1]<duration) points.push(duration);
  const minClip=positive(config.minClip,0.05);
  const cuts=[];
  for(let i=0;i<points.length-1;i++){
    const start=points[i], end=points[i+1];
    if(end-start>=minClip) cuts.push({start,duration:end-start});
  }
  if(cuts.length<2) throw new RenderRuntimeError('BEAT_CUT_TOO_FEW_SEGMENTS','Beat cut planner produced fewer than two usable segments.');
  return cuts;
}

function defaultWhisperCommand() {
  const bridge = path.join(path.dirname(fileURLToPath(import.meta.url)), 'whisper-transcribe.py');
  return `${process.env.PYTHON_BIN || 'python3'} ${bridge}`;
}

async function materializeImportedCaptions(config, dir) {
  const segments = Array.isArray(config?.segments) ? config.segments : [];
  if (!segments.length) {
    throw new RenderRuntimeError('CAPTION_IMPORT_EMPTY', 'Imported caption file contains no usable segments.');
  }
  const ass = path.join(dir, 'imported-captions.ass');
  await fs.writeFile(ass, makeASS(segments, config), 'utf8');
  return {segments, assFile: ass, source: 'manual-import'};
}

async function transcribeCaptions(rt,input,config,dir) {
  if(!rt.captionCommand) {
    throw new RenderRuntimeError('CAPTION_ENGINE_UNAVAILABLE',
      'AUTO CAPTION is active but no transcription runtime is configured. Set WHISPER_COMMAND to a Whisper-compatible CLI.');
  }
  const json=path.join(dir,'captions.json');
  const ass=path.join(dir,'captions.ass');
  // Command contract: command input output language. The command must produce JSON
  // [{start,end,text}] at the output path.
  const args=rt.captionCommand.split(/\s+/).filter(Boolean);
  const cmd=args.shift();
  try {
    await execFileAsync(cmd,[...args,input,json, String(config.language||'auto')]);
  } catch (error) {
    if (error?.code === 'RUNTIME_COMMAND_FAILED' && /No local Whisper backend is installed|ModuleNotFoundError|No module named/i.test(error.message)) {
      throw new RenderRuntimeError('CAPTION_BACKEND_MISSING', error.message);
    }
    throw error;
  }
  const raw=JSON.parse(await fs.readFile(json,'utf8'));
  const segments=Array.isArray(raw)?raw:raw.segments;
  if(!Array.isArray(segments) || !segments.length) throw new RenderRuntimeError('CAPTION_EMPTY','Transcription returned no caption segments.');
  await fs.writeFile(ass,makeASS(segments,config),'utf8');
  return {segments,assFile:ass};
}

function makeASS(segments,config) {
  const pos=String(config.position||'Bottom');
  const alignment=pos==='Top'?8:pos==='Center'?5:2;
  const style=String(config.style||'Clean');
  const fontSize=style==='Trend'?54:style==='Minimal'?38:44;
  const lines=[
    '[Script Info]','ScriptType: v4.00+','PlayResX: 1920','PlayResY: 1080','',
    '[V4+ Styles]','Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding',
    `Style: Default,Arial,${fontSize},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,3,1,${alignment},40,40,40,1`,'',
    '[Events]','Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text'
  ];
  for(const s of segments){
    lines.push(`Dialogue: 0,${assTime(s.start)},${assTime(s.end)},Default,,0,0,0,,${String(s.text||'').replace(/[{}]/g,'')}`);
  }
  return lines.join('\n');
}
function assTime(v){const n=Number(v)||0; const h=Math.floor(n/3600); const m=Math.floor((n%3600)/60); const s=Math.floor(n%60); const cs=Math.floor((n-Math.floor(n))*100); return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;}

async function runFiltered(rt,input,output,filters,report,meta) {
  const args=['-y','-i',input];
  if(filters.video.length || filters.audio.length){
    const parts=[];
    if(filters.video.length) parts.push(`[0:v]${filters.video.join(',')}[vout]`);
    if(filters.audio.length) parts.push(`[0:a]${filters.audio.join(',')}[aout]`);
    args.push('-filter_complex',parts.join(';'));
    if(filters.video.length) args.push('-map','[vout]');
    else args.push('-map','0:v:0');
    if(filters.audio.length) args.push('-map','[aout]');
    else args.push('-map','0:a:0?');
  } else {
    args.push('-map','0:v:0','-map','0:a:0?');
  }
  args.push('-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
    '-c:a','aac','-b:a','192k','-movflags','+faststart',output);
  await run(rt.ffmpegPath,args,p=>reportProgress(p,meta.label));
}

function run(cmd,args,onProgress=()=>{}) {
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd,args,{stdio:['ignore','ignore','pipe']});
    let stderr='';
    let progress=0;
    child.stderr.on('data',buf=>{
      const text=buf.toString(); stderr+=text;
      const m=text.match(/out_time_ms=(\d+)/g);
      if(m) { const v=Number(m[m.length-1].split('=')[1]); onProgress(Math.min(99,progressFromTime(v))); }
      const t=text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
      if(t) { const sec=+t[1]*3600 + +t[2]*60 + +t[3]; progress=Math.max(progress,sec); }
    });
    child.on('error',e=>reject(e));
    child.on('close',code=>{
      if(code===0) resolve();
      else reject(new RenderRuntimeError('FFMPEG_PROCESS_FAILED',`FFmpeg exited with code ${code}: ${lastLines(stderr,12)}`));
    });
  });
}
function progressFromTime(us){ return Math.min(99, us/1000000); }
function mapRange(p,a,b){return a+(b-a)*(Math.max(0,Math.min(100,p))/100);}
async function probeMedia(ffprobe,input){return JSON.parse(await execFileAsync(ffprobe,['-v','error','-show_entries','format=duration:stream=index,codec_type,width,height','-of','json',input])).format || {};}
async function assertFile(f){const s=await fs.stat(f).catch(()=>null);if(!s?.isFile())throw new RenderRuntimeError('INPUT_DECODE_FAILED',`Input file not found: ${f}`);}
async function ensureParent(f){await fs.mkdir(path.dirname(path.resolve(f)),{recursive:true});}
async function execFileAsync(cmd,args){return new Promise((res,rej)=>execFile(cmd,args,{maxBuffer:32*1024*1024},(e,stdout,stderr)=>e?rej(new RenderRuntimeError('RUNTIME_COMMAND_FAILED',`${cmd}: ${stderr||e.message}`)):res(stdout)));}
function escapeFilterPath(p){return String(p).replace(/\\/g,'\\\\').replace(/:/g,'\\:').replace(/'/g,"\\'");}
function num(v){const n=Number(v);if(!Number.isFinite(n))throw new RenderRuntimeError('INVALID_PARAMETER',`Invalid number: ${v}`);return n;}
function int(v){return Math.round(num(v));}
function positive(v,min){const n=num(v);if(n<min)throw new RenderRuntimeError('INVALID_PARAMETER',`Expected number >= ${min}, got ${v}`);return n;}
function median(a){if(!a.length)return 0;const x=[...a].sort((a,b)=>a-b);return x[Math.floor(x.length/2)];}
function lastLines(s,n){return s.split(/\r?\n/).filter(Boolean).slice(-n).join(' | ');}
class RenderRuntimeError extends Error {constructor(code,message){super(message);this.code=code;}}
