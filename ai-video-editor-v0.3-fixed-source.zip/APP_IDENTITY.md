# App Identity

The Android app identity is intentionally kept separate from the V0.3 editor core.

## Change the app name

Edit:

`mobile-app/capacitor.config.json`

Change:

`"appName": "AI Video Editor"`

to the desired display name, for example:

`"appName": "My Video AI"`

The Android application ID is controlled by `appId` and should **not** be changed casually after publishing because Android treats it as the package identity.

## Change the package ID

Only do this if you intentionally want a new Android application identity. Update:

`mobile-app/capacitor.config.json`

For example:

`"appId": "com.example.myvideoai"`

Then regenerate/sync the Android project and rebuild.

## Safe upgrade rule

App-name changes do not require changes to the V0.3 Registry, Action Store, Planner, Render Graph, or FFmpeg core. They are presentation/build-layer changes only.
