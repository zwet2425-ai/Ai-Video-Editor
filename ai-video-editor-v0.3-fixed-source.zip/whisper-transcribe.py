#!/usr/bin/env python3
"""AI Video Editor V0.3 local Whisper bridge.

Contract:
  python3 whisper-transcribe.py INPUT OUTPUT_JSON LANGUAGE

Uses faster-whisper when available, otherwise openai-whisper.
The output is always [{"start": float, "end": float, "text": str}].
"""
import json, os, sys


def normalize_language(value):
    value = (value or "auto").strip()
    aliases = {"Auto Detect": "auto", "Auto": "auto", "auto-detect": "auto"}
    return aliases.get(value, value.lower())


def write_json(path, segments):
    cleaned = []
    for s in segments:
        text = str(s.get("text", "")).strip()
        start = float(s.get("start", 0.0))
        end = float(s.get("end", start))
        if text and end > start:
            cleaned.append({"start": start, "end": end, "text": text})
    if not cleaned:
        raise RuntimeError("Whisper returned no usable caption segments.")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cleaned, f, ensure_ascii=False, indent=2)


def run_faster_whisper(input_path, language):
    from faster_whisper import WhisperModel
    model_name = os.environ.get("WHISPER_MODEL", "small")
    device = os.environ.get("WHISPER_DEVICE", "auto")
    compute = os.environ.get("WHISPER_COMPUTE_TYPE", "auto")
    model = WhisperModel(model_name, device=device, compute_type=compute)
    lang = None if language == "auto" else language
    segments, info = model.transcribe(
        input_path,
        language=lang,
        vad_filter=True,
        beam_size=int(os.environ.get("WHISPER_BEAM_SIZE", "5")),
    )
    return [{"start": s.start, "end": s.end, "text": s.text} for s in segments]


def run_openai_whisper(input_path, language):
    import whisper
    model_name = os.environ.get("WHISPER_MODEL", "small")
    model = whisper.load_model(model_name)
    kwargs = {}
    if language != "auto":
        kwargs["language"] = language
    result = model.transcribe(input_path, **kwargs)
    return [
        {"start": s["start"], "end": s["end"], "text": s["text"]}
        for s in result.get("segments", [])
    ]


def main():
    if len(sys.argv) < 4:
        print("usage: whisper-transcribe.py INPUT OUTPUT_JSON LANGUAGE", file=sys.stderr)
        return 2
    input_path, output_path, language = sys.argv[1:4]
    language = normalize_language(language)
    errors = []
    try:
        segments = run_faster_whisper(input_path, language)
        write_json(output_path, segments)
        return 0
    except ImportError as e:
        errors.append(f"faster-whisper unavailable: {e}")
    except Exception as e:
        print(f"faster-whisper failed: {e}", file=sys.stderr)
        return 3
    try:
        segments = run_openai_whisper(input_path, language)
        write_json(output_path, segments)
        return 0
    except ImportError as e:
        errors.append(f"openai-whisper unavailable: {e}")
    except Exception as e:
        print(f"openai-whisper failed: {e}", file=sys.stderr)
        return 3
    print("No local Whisper backend is installed. " + " | ".join(errors) + ". Install faster-whisper (recommended) or openai-whisper.", file=sys.stderr)
    return 4


if __name__ == "__main__":
    raise SystemExit(main())
