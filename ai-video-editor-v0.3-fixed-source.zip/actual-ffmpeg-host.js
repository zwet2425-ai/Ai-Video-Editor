/**
 * Example host integration for the locked V0.3 pipeline.
 *
 * This is intentionally outside the browser UI. An Electron/Node host can:
 *   1. receive the user's original File path
 *   2. buildRenderGraph from the existing Execution Plan
 *   3. compileFFmpegGraph for inspection/debugging
 *   4. createRenderJob
 *   5. execute with createNodeFFmpegExecutor
 *
 * Browser preview/fallback remains untouched.
 */
import { buildRenderGraph } from './render-graph.js';
import { compileFFmpegGraph } from './ffmpeg-graph.js';
import { createRenderJob, runRenderJob } from './render-worker.js';
import { createNodeFFmpegExecutor } from './ffmpeg-runtime-node.js';

export async function renderWithActualFFmpeg({input, output, executionPlan, media = {}, onUpdate = console.log}) {
  const graph = buildRenderGraph({input, output, plan: executionPlan, media});
  const compiled = compileFFmpegGraph(graph);
  const job = createRenderJob({input, output, graph, compiled});
  return runRenderJob(job, createNodeFFmpegExecutor(), onUpdate);
}
