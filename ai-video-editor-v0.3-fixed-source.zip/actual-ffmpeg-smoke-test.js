import { promises as fs } from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import os from 'node:os';
import { buildRenderGraph } from './render-graph.js';
import { compileFFmpegGraph } from './ffmpeg-graph.js';
import { createRenderJob, runRenderJob } from './render-worker.js';
import { createNodeFFmpegExecutor } from './ffmpeg-runtime-node.js';

const exec = promisify(execFile);
const dir = await fs.mkdtemp(path.join(os.tmpdir(),'aive-test-'));
const input=path.join(dir,'input.mp4'), output=path.join(dir,'output.mp4');

await exec('ffmpeg',['-y','-f','lavfi','-i','testsrc2=size=640x360:rate=30','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','6',
  '-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-c:a','aac','-shortest',input]);

const plan=[
 {step:1,id:'split',name:'SPLIT',params:{mode:'Duration',duration:'2'}},
 {step:2,id:'trim',name:'TRIM',params:{start:'00:00:00',end:'00:00:05'}},
 {step:3,id:'speed',name:'SPEED',params:{speed:'1.25',applyTo:'Entire Video'}},
 {step:4,id:'crop',name:'CROP',params:{width:'600',height:'320',x:'20',y:'20'}},
 {step:5,id:'resize',name:'RESIZE',params:{width:'640',height:'360',lock:true}}
];
const graph=buildRenderGraph({input,output,plan,media:{}});
const compiled=compileFFmpegGraph(graph);
const job=createRenderJob({input,output,graph,compiled});
await runRenderJob(job,createNodeFFmpegExecutor(),u=>console.log(u.status,u.progress,u.message));
const st=await fs.stat(output);
if(!st.size) throw new Error('Output file is empty');
const {stdout}=await exec('ffprobe',['-v','error','-show_entries','format=duration,size','-of','json',output]);
console.log('ACTUAL FFMPEG SMOKE TEST: PASS');
console.log(stdout);
await fs.rm(dir,{recursive:true,force:true});
