/**
 * V0.3 Specialized Render Graph
 * Converts the locked Execution Plan into deterministic render stages.
 *
 * This is an engine planner: it does not execute FFmpeg itself.
 * A worker/backend can consume the returned graph.
 */

export function buildRenderGraph({ input, output, plan, media = {} }) {
  const stages = [];
  const warnings = [];

  const active = new Set(plan.map(x => x.id));
  const add = (type, id, config = {}) => stages.push({
    index: stages.length + 1, type, id, config
  });

  for (const step of plan) {
    const p = step.params || {};

    switch (step.id) {
      case 'split':
        add('segment', 'split', {
          mode: p.mode,
          duration: timeToSeconds(p.duration),
          strategy: 'materialize-segments'
        });
        break;

      case 'trim':
        add('temporal', 'trim', {
          start: timeToSeconds(p.start),
          end: timeToSeconds(p.end)
        });
        break;

      case 'speed':
        add('temporal', 'speed', {
          factor: positive(p.speed, 0.01),
          applyTo: p.applyTo
        });
        break;

      case 'speedRamp':
        add('temporal', 'speed-ramp', {
          mode: p.mode,
          start: positive(p.start, 0.01),
          peak: positive(p.peak, 0.01),
          end: positive(p.end, 0.01),
          duration: positive(p.duration, 0.01)
        });
        break;

      case 'crop':
        add('geometry', 'crop', {
          mode: p.mode,
          width: positive(p.width, 1),
          height: positive(p.height, 1),
          x: nonnegative(p.x),
          y: nonnegative(p.y)
        });
        break;

      case 'resize':
        add('geometry', 'resize', {
          width: positive(p.width, 1),
          height: positive(p.height, 1),
          lock: !!p.lock
        });
        break;

      case 'zoomMotion':
        add('motion', 'zoom-motion', {
          mode: p.mode,
          amount: clamp(Number(p.amount) || 1, 1, 4),
          duration: positive(p.duration, 0.01),
          direction: p.direction,
          applyTo: p.applyTo
        });
        break;

      case 'transition':
        add('composite', 'transition', {
          mode: p.mode,
          duration: positive(p.duration, 0),
          applyTo: p.applyTo,
          requiresSegments: true
        });
        if (!active.has('split')) {
          warnings.push('TRANSITION requires segment boundaries; planner will materialize segments.');
        }
        break;

      case 'beatSync':
        add('analysis', 'beat-analysis', {
          mode: p.mode,
          sensitivity: clamp(Number(p.sensitivity) || 0, 0, 100),
          offsetMs: Number(p.offset) || 0
        });
        add('temporal-map', 'beat-sync', {
          mode: p.mode,
          source: 'beat-analysis'
        });
        break;

      case 'beatCut':
        add('analysis', 'beat-analysis', {
          mode: 'cut',
          sensitivity: clamp(Number(p.sensitivity) || 0, 0, 100),
          offsetMs: Number(p.offset) || 0
        });
        add('segment', 'beat-cut', {
          frequency: p.frequency,
          minClip: positive(p.minClip, 0.05),
          source: 'beat-analysis'
        });
        break;

      case 'caption':
        if (Array.isArray(p.segments) && p.segments.length) {
          add('analysis', 'caption-import', {
            language: p.language,
            engine: 'manual-import',
            sourceFormat: p.sourceFormat || 'srt',
            segments: p.segments
          });
        } else {
          add('analysis', 'transcription', {
            language: p.language,
            engine: 'auto'
          });
        }
        add('overlay', 'captions', {
          style: p.style,
          position: p.position,
          animation: p.animation,
          source: (Array.isArray(p.segments) && p.segments.length) ? 'caption-import' : 'transcription'
        });
        break;

      default:
        warnings.push(`Unknown function registry id: ${step.id}`);
    }
  }

  // De-duplicate analysis stages while preserving first-use order.
  const seen = new Set();
  const deduped = stages.filter(s => {
    const key = `${s.type}:${s.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map((s,i)=>({...s,index:i+1}));

  return {
    version: '0.3',
    input,
    output,
    media,
    stages: deduped,
    warnings,
    outputPolicy: {
      nonDestructive: true,
      overwriteSource: false,
      container: 'mp4',
      videoCodec: 'libx264',
      audioCodec: 'aac',
      fastStart: true
    }
  };
}

function positive(v, min) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min) throw new Error(`Expected number >= ${min}, got ${v}`);
  return n;
}
function nonnegative(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) throw new Error(`Expected nonnegative number, got ${v}`);
  return n;
}
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function timeToSeconds(v) {
  const parts = String(v).split(':').map(Number);
  if (parts.some(Number.isNaN)) throw new Error(`Invalid time: ${v}`);
  if (parts.length === 3) return parts[0]*3600 + parts[1]*60 + parts[2];
  if (parts.length === 2) return parts[0]*60 + parts[1];
  return Number(parts[0]) || 0;
}
