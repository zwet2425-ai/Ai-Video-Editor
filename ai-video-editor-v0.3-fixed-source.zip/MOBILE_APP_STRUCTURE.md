# V0.3 Mobile App Structure

The Android app is deliberately separated from the V0.3 Render Core.

```text
ai-video-editor-v0.3/
├── app.js                         # existing editor UI/state
├── render-graph.js                # existing render graph
├── ffmpeg-graph.js                # existing compiler
├── render-worker.js               # existing worker contract
├── ffmpeg-runtime-node.js         # existing desktop/node runtime
├── manual-caption-*               # existing caption fallback
│
└── mobile-app/                    # NEW additive mobile layer
    ├── capacitor.config.json
    ├── package.json
    ├── www/
    │   ├── index.html
    │   ├── styles.css
    │   ├── app.js
    │   └── mobile-runtime.js
    └── android-runtime/
        └── AIVideoRuntimePlugin.md
```

### Rule

`mobile-app` is an adapter/shell. It must never duplicate or replace the core
Registry, Action Store, Planner, or Render Graph.
