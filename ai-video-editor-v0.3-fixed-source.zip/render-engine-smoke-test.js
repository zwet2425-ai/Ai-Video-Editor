/**
 * V0.3 engine smoke tests.
 * Run with a JS runtime that supports ES modules.
 */
import { buildRenderGraph } from './render-graph.js';
import { compileFFmpegGraph } from './ffmpeg-graph.js';

const plan = [
  {id:'trim', params:{start:'00:00:02',end:'00:00:20'}},
  {id:'speed', params:{speed:'1.25',applyTo:'Entire Video'}},
  {id:'crop', params:{mode:'Center',width:'1080',height:'1080',x:'0',y:'0'}},
  {id:'resize', params:{width:'1080',height:'1080',lock:true}},
  {id:'zoomMotion', params:{mode:'Auto Zoom',amount:'1.15',duration:'1',direction:'In',applyTo:'Entire Video'}},
  {id:'caption', params:{language:'Auto Detect',style:'Trend',position:'Bottom',animation:'Pop'}}
];

const graph = buildRenderGraph({
  input:'input.mp4',
  output:'output.mp4',
  plan,
  media:{width:1920,height:1080,duration:120}
});

const compiled = compileFFmpegGraph(graph);

if (!graph.stages.length) throw new Error('No render stages generated.');
if (!compiled.filterComplex.video.includes('trim')) throw new Error('TRIM not compiled.');
if (!compiled.filterComplex.video.includes('setpts')) throw new Error('SPEED not compiled.');
if (!compiled.filterComplex.video.includes('crop')) throw new Error('CROP not compiled.');
if (!compiled.filterComplex.video.includes('scale')) throw new Error('RESIZE/ZOOM not compiled.');
if (!compiled.notes.some(x=>x.stage==='captions')) throw new Error('CAPTION stage missing.');

console.log('V0.3 render graph smoke test: PASS');
console.log(JSON.stringify({stages:graph.stages,compiled},null,2));
